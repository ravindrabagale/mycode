fruits=(apple banana chiku)
echo "${fruits[*]}"
echo "${fruits[1]}"
echo "${fruits[0]}"


marks[0]=78
marks[1]=89
marks[2]=56

echo "${marks[*]}"
