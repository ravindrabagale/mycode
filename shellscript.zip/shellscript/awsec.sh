
for TOKEN in $*
do
  aws ec2 stop-instances --instance-id $TOKEN
done
