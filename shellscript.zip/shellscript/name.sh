echo please enter your first name;
read name
#echo $name
echo please enter your last name;
read lname
echo $name $lname
mkdir $name $lname
unset name 
echo value of name is $name
