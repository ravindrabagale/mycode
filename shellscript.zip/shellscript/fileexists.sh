if [ -e ravi.text ]
then
 echo "file exists"
else
  echo "file not exists, so creating file"
  touch ravi.text
  echo "written by shell script" > ravi.text
fi 
