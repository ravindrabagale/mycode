
for i in 1,2,3,4,5,6,7,8,9
do
   echo $i
done


for i in `seq 1 10`
do
 echo $RANDOM
done

for i in `seq 1 2 10`
do
 echo $i
done

for i in `seq 10 -2 1`
do
 echo $i
done

