while :
do
 echo I
 sleep 1
echo LOVE
 sleep 1
 echo YOU
done
