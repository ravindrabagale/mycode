if [ $UID -eq 0 ]
then
  echo "this is root user"
else
  echo "this is non root user"
fi
