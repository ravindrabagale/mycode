x=5
echo $x

if [ $x -ge 4 ]
then 
echo "x is greater than 4"
else
echo "x is less than 5"
fi
